package ExamenCMarisa;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.Period;

public abstract class Trabajador {
	protected String dni;
	protected LocalDate fechaContratacion;
	protected BigDecimal sueldoBase;

	public Trabajador(String dni) {
		super();
		this.dni = dni;

	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public LocalDate getFechaContratacion() {
		return fechaContratacion;
	}

	public void setFechaContratacion(LocalDate fechaContratacion) {
		this.fechaContratacion = fechaContratacion;
	}

	public BigDecimal getSueldoBase() {
		return sueldoBase;
	}

	public void setSueldoBase(BigDecimal sueldoBase) {
		this.sueldoBase = sueldoBase;
	}

	public int getAntiguedad() {
		Period periodo = fechaContratacion.until(LocalDate.now());
		int antiguedad = periodo.getYears();
		return antiguedad;
	}

	public Boolean puedeJubilarse() {
		if (getAntiguedad() < 30) {
			return false;
		}
		return true;
	}

	public abstract BigDecimal getSueldoActual();

	@Override
	public String toString() {
		return "Trabajador " + dni + "contratado el " + fechaContratacion + " y con sueldo actual" + getSueldoActual();
	}

}
