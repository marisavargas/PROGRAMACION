package ExamenCMarisa;

import java.math.BigDecimal;

public class Especialista extends Trabajador {
	public Especialista(String dni) {
		super(dni);

	}

	public static final BigDecimal SUELDOESPECIALISTA = new BigDecimal(1000);

	@Override
	public BigDecimal getSueldoActual() {

		BigDecimal plusAntiguedad = SUELDOESPECIALISTA.multiply(new BigDecimal(getAntiguedad()));

		return sueldoBase.add(plusAntiguedad);

	}
}
