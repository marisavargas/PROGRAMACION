package ExamenCMarisa;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class TextExamenC {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		/*
		 * System.out.println("Indique  un dni de 9 caracteres:"); String dni =
		 * sc.nextLine(); if (!(dni.length() == 9)) {
		 * System.out.println("Dni incorrecto introduzca otro:");
		 * 
		 * } else { System.out.println(dni);
		 * 
		 * } /*System.out.println("introduzca el sueldo"); BigDecimal salario = new
		 * BigDecimal(0);
		 * 
		 * /* if (salario.compareTo(Trabajados.setSueldoBase))<1000{ System.out.
		 * println("Indique el sueldo base de trabajador (mayoo o igual) a 10000:");
		 * 
		 * }else { System.out.println( "el salario del trabajador es :");
		 */

		Fabrica fabrica1 = new Fabrica("Blas S.A");
		System.out.println(fabrica1);

		Cualificado traba1cuali = new Cualificado("12345678A");
		LocalDate fecha1 = LocalDate.of(1981, 1, 3);
		traba1cuali.setFechaContratacion(fecha1);
		Especialista traba2especial = new Especialista("87654321B");
		LocalDate fecha2 = LocalDate.of(1999, 12, 7);
		traba2especial.setFechaContratacion(fecha2);

		DateTimeFormatter formato = DateTimeFormatter.ofPattern("dd/MM/yyyy");

	}
}
