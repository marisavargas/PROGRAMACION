package ExamenCMarisa;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

public class Fabrica {
	private String nombreComercial;
	private List<Trabajador> trabajadores;

	public Fabrica(String nombreComercial) {
		super();
		this.nombreComercial = nombreComercial;
		this.trabajadores = new ArrayList<>();

	}

	public String getNombreComercial() {
		return nombreComercial;
	}

	public void setNombreComercial(String nombreComercial) {
		this.nombreComercial = nombreComercial;
	}

	public List<Trabajador> getTrabajadores() {
		return trabajadores;
	}

	public void setTrabajadores(List<Trabajador> trabajadores) {
		this.trabajadores = trabajadores;
	}

	public List<Trabajador> getTrabajadoresJunior() {
		List<Trabajador> masAntiguos = new ArrayList<>();
		for (Trabajador trabajador : trabajadores) {
			if (trabajador.getAntiguedad() < 1) {
				masAntiguos.add(trabajador);

			}

		}
		return masAntiguos;

	}

	public Boolean existeTrabajador(String dni) {
		for (Trabajador trabajador : trabajadores) {
			if (trabajador.getDni().equalsIgnoreCase(dni)) {

				return true;
			}

		}
		return false;

	}
	/*
	 * public Integer actualizarSueldoBase( Integer año , (new BigDecimal(sueldo)))
	 * { for (Trabajador trabajador : trabajadores) {
	 * if(trabajador.getFechaContratacion().getYear()== año) {
	 * trabajador.getSueldoBase().add(sueldo); } } return actualizarSueldoBase ;
	 */

	public BigDecimal getAhorroCosteJubilacion() {
		BigDecimal sumaSueldos = new BigDecimal(0);
		for (Trabajador trabajador : trabajadores) {
			sumaSueldos = sumaSueldos.add(trabajador.getSueldoActual());

		}
		return sumaSueldos.setScale(2, RoundingMode.HALF_DOWN);

	}
	/*
	 * public Trabajador getTrabajadorDecano() {
	 * 
	 * for (Trabajador trabajador : trabajadores) {
	 * if(trabajador.getFechaContratacion().isAfter(trabajador.getFechaContratacion(
	 * ))) {
	 * 
	 * }return trabajador;
	 */

}
