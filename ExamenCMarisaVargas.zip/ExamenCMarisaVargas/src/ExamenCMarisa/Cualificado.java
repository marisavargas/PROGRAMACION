package ExamenCMarisa;

import java.math.BigDecimal;

public class Cualificado extends Trabajador {
	public Cualificado(String dni) {
		super(dni);

	}

	private String especialidad;
	public static final BigDecimal SUELDOCUALIFICADO = new BigDecimal(3000);

	public String getEspecialidad() {
		return especialidad;
	}

	public void setEspecialidad(String especialidad) {
		this.especialidad = especialidad;
	}

	@Override
	public BigDecimal getSueldoActual() {

		BigDecimal plusAntiguedad = SUELDOCUALIFICADO.multiply(new BigDecimal(getAntiguedad()));

		return sueldoBase.add(plusAntiguedad);
	}

}
